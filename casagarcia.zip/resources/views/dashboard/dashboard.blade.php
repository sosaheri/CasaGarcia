@extends('layouts.dashboard')




@section('content')

    
        <div class="main-panel">

            @include('layouts.navbar')
    
    
            <div class="content">
                <div class="container-fluid">
                    <div class="row">

                    </div>

                </div>
            </div>
    
    
            @include('layouts.footer')
    
        </div>



@endsection
