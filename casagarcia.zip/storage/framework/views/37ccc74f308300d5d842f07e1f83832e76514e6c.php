<?php $__env->startSection('content'); ?>

    
        <div class="main-panel">

            <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    
            <div class="content">
                <div class="container-fluid">
                    <div class="row">

                    </div>

                </div>
            </div>
    
    
            <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
        </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectos\casagarcia\resources\views/dashboard/dashboard.blade.php ENDPATH**/ ?>