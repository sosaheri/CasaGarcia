<footer class="footer">
        <div class="container-fluid">
            <nav class="pull-left">
                <ul>

                    <li>
                        <a mailto="info@larepaweb.com.ve">
                                
                            Solicita Soporte
                            <i class="ti-support"></i>
                        </a>
                    </li>

                </ul>
            </nav>
            <div class="copyright pull-right">
                &copy; <script>document.write(new Date().getFullYear())</script>, made with <i class="ti-heart"></i> by <a href="http://www.larepaweb.com.ve">Arepa Web Group</a>
            </div>
        </div>
    </footer><?php /**PATH C:\xampp\htdocs\proyectos\casagarcia\resources\views/layouts/footer.blade.php ENDPATH**/ ?>