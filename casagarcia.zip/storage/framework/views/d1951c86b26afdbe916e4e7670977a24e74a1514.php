<?php $__env->startSection('content'); ?>

    
        <div class="main-panel">

            <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    
            <div class="content">
                    <div class="container-fluid">

                            <?php if($message = Session::get('success')): ?>
                            <div class="alert alert-success">
                                <p><?php echo e($message); ?></p>
                            </div>
                            <?php endif; ?>

                            <div class="row">
                                    <div class="col-md-12">
                                        <div class="card">
                                            <div class="row">
                                                    <div class="card header">
                                                            <h4 class="title">Biblioteca de medios</h4>
                                                            
                                                    </div>

                                            </div>

                                            <div class="row container flex">
                                                    <?php $__currentLoopData = $medias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                    <div class="col-lg-4 col-sm-6">
                                                        <div class="thumbnail">
                                                            <img src="<?php echo e(asset('storage')); ?>/<?php echo e($media->url); ?>">
                                                        </div>

                                                        <div>
                                                                
                                                            <a href="<?php echo e(url('eliminarImagen', [$media->id] )); ?>"><button type="submit" class="btn btn-danger">Eliminar</button></a>
                                                             <p><?php echo e($media->category); ?></p>   
                                                        </div>
                                                    </div>

                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        
                                                </div>


                                         
                                        </div>
                                    </div>
                
                
                                   
                
                
                                </div>        
                    </div>
            </div>
    
    
            <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
        </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectos\casagarcia\resources\views/dashboard/images/index.blade.php ENDPATH**/ ?>