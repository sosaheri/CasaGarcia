<?php $__env->startSection('content'); ?>

    
        <div class="main-panel">

            <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    
            <div class="content">
                    <div class="container-fluid">
                            <div class="row">

                                    <?php if($message = Session::get('success')): ?>
                                    <div class="alert alert-success">
                                        <p><?php echo e($message); ?></p>
                                    </div>
                                    <?php endif; ?>

                                    <?php if($message = Session::get('error')): ?>
                                    <div class="alert alert-alert">
                                        <p><?php echo e($message); ?></p>
                                    </div>
                                    <?php endif; ?>
                                
                                <div class="col-lg col-md">
                                    <div class="card">
                                        <div class="header">
                                            <h4 class="title">Cargar Media</h4>
                                        </div>
                                        <div class="content">
                                        <form method="POST" action="<?php echo e(route('guardarImagen')); ?>" accept-charset="UTF-8" enctype="multipart/form-data">
                                                
                                                <input type="hidden" name="type" value="image">
            
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label>Cargar archivo</label>
                                                            <input type="file" name="ruta" class="form-control border-input" placeholder="Cargar Archivo" >
                                                        </div>
                                                    </div>
 
                                                </div>

                                                <div class="row">
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label>Elegir Categoria</label>
                                                                <select name="category" id="category" class="form-control border-input">
                                                                <option value="sociales">Sociales</option>
                                                                <option value="gubernamental">Gubernamental</option>
                                                                <option value="empresarial">Empresarial</option>
                                                                <option value="catering-inmobiliario">Catering / Inmobiliario</option>
                                                                </select>
                                                            </div>
                                                        </div>
     
                                                    </div>
            
                                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                                <div class="text-center">
                                                    <button type="submit" class="btn btn-info btn-fill btn-wd">Guardar</button>
                                                </div>
                                                <div class="clearfix"></div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
            
            
                            </div>
                        </div>
            </div>
    
    
            <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
        </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectos\casagarcia\resources\views/dashboard/images/create.blade.php ENDPATH**/ ?>